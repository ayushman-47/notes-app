const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

// Create a file to stream archive data to
const output = fs.createWriteStream('diamond-notes-source-code.zip');
const archive = archiver('zip', {
  zlib: { level: 9 } // Sets the compression level
});

// Listen for all archive data to be written
output.on('close', function() {
  console.log('Source code archive created successfully!');
  console.log('File: diamond-notes-source-code.zip');
  console.log('Size: ' + archive.pointer() + ' bytes');
});

// Good practice to catch warnings (ie stat failures and other non-blocking errors)
archive.on('warning', function(err) {
  if (err.code === 'ENOENT') {
    // log warning
  } else {
    // throw error
    throw err;
  }
});

// Good practice to catch this error explicitly
archive.on('error', function(err) {
  throw err;
});

// Pipe archive data to the file
archive.pipe(output);

// Add files and directories
const excludeDirs = ['node_modules', '.git', '.cache', '.local'];
const excludeFiles = ['.replit', '.replit.nix', '.env'];

function shouldExclude(filePath) {
  const normalizedPath = filePath.replace(/\\/g, '/');
  
  // Check if path contains excluded directories
  for (const dir of excludeDirs) {
    if (normalizedPath.includes(dir + '/') || normalizedPath.endsWith(dir)) {
      return true;
    }
  }
  
  // Check if file is in excluded files
  const fileName = path.basename(filePath);
  return excludeFiles.includes(fileName);
}

function addDirectory(dirPath, archiveDir = '') {
  const files = fs.readdirSync(dirPath);
  
  files.forEach(file => {
    const fullPath = path.join(dirPath, file);
    const archivePath = archiveDir ? path.join(archiveDir, file) : file;
    
    if (shouldExclude(fullPath)) {
      return;
    }
    
    const stat = fs.statSync(fullPath);
    
    if (stat.isDirectory()) {
      addDirectory(fullPath, archivePath);
    } else {
      archive.file(fullPath, { name: archivePath });
    }
  });
}

// Add all files from current directory
addDirectory('.');

// Finalize the archive (ie we are done appending files but streams have to finish yet)
archive.finalize();